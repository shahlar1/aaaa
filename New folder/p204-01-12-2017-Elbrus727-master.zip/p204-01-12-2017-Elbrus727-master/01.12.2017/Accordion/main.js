$(document).ready(function(){
    $(".header").click(function(){
        // $(".active").slideUp().removeClass("active");
        // $(this).next().toggleClass("active").slideToggle();

        if($(this).hasClass("active")){
            $(this).removeClass("active").next().slideUp().prev().find("span").css("transform", "rotate(0deg)");
        }else{
            $(".active").removeClass("active").next().slideUp().prev().find("span").css("transform", "rotate(0deg)");
            $(this).addClass("active").next().slideDown().prev().find("span").css("transform", "rotate(45deg)");
        }
    })
})