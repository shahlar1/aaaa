$(function(){

    // Show all
    $("button:nth-child(1)").click(function(){
        $(".main div").hide().fadeIn(1000);
    })

    // Show first half
    $("button:nth-child(2)").click(function(){
        var middle = $(".main div").length/2;
        $(".main div").hide().slice(0, middle).fadeIn(1000);
    })

    // Show second half
    $("button:nth-child(3)").click(function(){
        var middle = $(".main div").length/2;
        $(".main div").hide().slice(middle).fadeIn(1000);
    })

    // Show odd
    $("button:nth-child(4)").click(function(){
        $(".main div").hide().filter(":nth-child(odd)").fadeIn(1000);
    })

    // Show even
    $("button:nth-child(5)").click(function(){
        $(".main div").hide().filter(":nth-child(even)").fadeIn(1000);
    })

    // Show divisible by 3
    $("button:nth-child(6)").click(function(){
        showDivisibles(3);
    })

    // Show divisible by 5
    $("button:nth-child(7)").click(function(){
        showDivisibles(5);
    })

    // Show divisible by 7
    $("button:nth-child(8)").click(function(){
        showDivisibles(7);
    })

    // Function for showing divisible items
    function showDivisibles(number){
        $(".main div").hide();
        $(".main div").each(function(index, item){
            if((index+1) % number == 0){
                $(item).fadeIn(700);
            }
        })
    }
})