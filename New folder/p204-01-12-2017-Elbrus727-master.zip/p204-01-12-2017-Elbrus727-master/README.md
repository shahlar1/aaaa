# p204-01-12-2017

### Tapşırıq (Jquery)
- Ortada dairəvi bir div olacaq. Üzərinə 2 dəfə click olunduqda, ardıcıl olaraq həmin div əvvəlcə sağa yuxarıya, sonra sağa aşağıya, sola aşağıya, sola yuxarıya və sonda əvvəlki yerinə qayıdacaq. Bütün yolları getməsi görünməlidir, yəni burdan yox olub, yuxarıdan çıxmamalıdır.
- User document-də mouse-u hərəkət elətdirdikcə, ən son 10 nöqtəninin hər biri üçün bir div yaratmalıdır. Əgər 10 nöqtədə olubsa, yəni 10 dənə div yaralıbsa, ən birinci yaradılan div-i silməli və ən sonuncu nöqtə üçün olan div-i body-ə append etməlidir. Bunu count variable-i yaradaraq nizamlaya bilərsiniz. Div-lər dairəvi olarsa, sizdə snake oyununa bənzər bir şey alınacaq.
- Window-un resize eventi üçün bir tapşırıq. Deməli, window resize olunduqca, bir dənə h1 tag-inin daxilində "Hazırki window ekran width-i bu ölçüdədir: ..." kimi bir yazı yazılmalıdır və orada ekranın ölçüsü görsənməlidir.

Bu tapşırıqlardan hər biri yazılmalıdır. 1-ci və 3-cü tapşırıqlar çox asandır. 2-ciyə də qətiyyən böyük vaxt lazım deyil. Hamısını rahatlıqla çatdıra biləcəksiniz.

*Xoş həftəsonu. Uğurlar.*
