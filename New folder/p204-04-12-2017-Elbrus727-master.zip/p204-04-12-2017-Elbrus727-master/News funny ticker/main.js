$(document).ready(function(){
	var last=7;

	$('.fa-chevron-down').click(function(){
		down();
	});

	$('.fa-chevron-up').click(function(){
		up();
	});

	$(document).keydown(function(event){
		if(event.keyCode==38){
			up();
		}else if(event.keyCode==40){
			down();
		}
	});

	function down(){
		last++;
		if(last==($('.wrapper').size()))
			last=0;
		change();
	}

	function up(){
		last--;
		if(last==0)
			last=$('.wrapper').size();
		change();
	}

	function change(){
		$('.wrapper').eq(last-1).attr('class','wrapper bottom3');
		$('.wrapper').eq(last-2).attr('class','wrapper bottom2');
		$('.wrapper').eq(last-3).attr('class','wrapper bottom1');
		$('.wrapper').eq(last-4).attr('class','wrapper active');
		$('.wrapper').eq(last-5).attr('class','wrapper top3');
		$('.wrapper').eq(last-6).attr('class','wrapper top2');
		$('.wrapper').eq(last-7).attr('class','wrapper top1');
		$('.wrapper').eq(last-8).attr('class','wrapper');
		$('.wrapper').eq(last).attr('class','wrapper');
	}
});