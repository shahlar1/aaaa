# p204-04-12-2017

##### Tapşırıq (Jquery)
- Video linkle tapsirigi gonderecem. Orda olan animation-u yazmalisiniz. Dairenin boyukluyunu (radiusunu) ve suretini input ile goture bilersiniz. Rengi ise input[type=color] ile goture bilersiniz. Her hansi bir ozellik deyisirse, hemin anda dairede deyisiklik olmalidir. Animation ise durmadan davam etmelidir.

Sabah saat 2-e qeder vaxtiniz var.

*Sabaha qədər. Uğurlar.*
