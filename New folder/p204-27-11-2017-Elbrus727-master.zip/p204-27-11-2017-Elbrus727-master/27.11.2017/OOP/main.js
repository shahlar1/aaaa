// Manual object creation

// var Elbrus = {
//     // property
//     name: "Elbrus",
//     surname: "Eliyev",
//     email: "elbrus@code.edu.az",

//     // method
//     getFullInfo: function(){
//         return this.name + " " + this.surname + " " + this.email;
//     }

// }

// var Samir = {
//     // property
//     name: "Samir",
//     surname: "Hesenov",
//     email: "samir@code.edu.az",

//     // method
//     getFullInfo: function(){
//         return this.name + " " + this.surname + " " + this.email;
//     }

// }
// console.log(Elbrus.getFullInfo());
// console.log(Samir.getFullInfo());


// Constructor

// var students = [];

// var Student = function(name, surname, email, group){
//     this.name = name,
//     this.surname = surname,
//     this.email = email,
//     this.group = group,
//     this.homeworks = [],

//     this.getFullInfo = function(){
//         return this.name + " | " + this.surname + " | " + this.email + " | " + this.group;
//     },

//     this.addHomework = function(subject, score){
//         this.homeworks.push(
//             {fenninAdi: subject, bal: score}
//         );
//     }

//     students.push(this);
// }

// var Elbrus = new Student("Elbrus", "Eliyev", "elbrus@code.az", "P204");
// Elbrus.addHomework("HTML", 89);
// Elbrus.addHomework("CSS", 77);
// Elbrus.addHomework("JS", 100);

// var resultString = "Telebe " + Elbrus.name + " " + Elbrus.surname + " asagidaki fenlerden imtahan vermisdir:\n";
// for(var i = 0; i < Elbrus.homeworks.length; i++){
//     var item = Elbrus.homeworks[i];
//     resultString += (item.fenninAdi+ ": " + item.bal + "\n");
// }

// console.log(resultString);

// var Samir = new Student("Samir", "Hesenov", "samir@code.az", "P204");
// var Aqsin = new Student("Aqsin", "Huseynov", "aqsin@code.az", "P204");
// var Elnur = new Student("Elnur", "MC", "elnur@code.az", "P204");
 

// for(var i = 0; i < students.length; i++){
//     console.log(students[i].getFullInfo());
// }


// var homeworks = [
//     {subject: "math", score: 75},
//     {subject: "english", score: 69},
//     {subject: "physics", score: 86},
//     {subject: "chemistry", score: 67}

// ]


function Car(marka, model, year, color, motor, fuelEf){
    this.marka = marka,
    this.model = model,
    this.year = year,
    this.color = color,
    this.motor = motor,
    this.fuelEf = fuelEf,
    this.serfiyyat = function(distance){
        var result = this.marka.toUpperCase() + " " + this.model.toUpperCase() + " " + distance + " km-e " + distance/100 * this.fuelEf + " lt benzin serf edir.";
        return result;
    }
}

function add(a,b){
    return a+b;
}

var bmw = new Car("bmw", "x5", 2015, "red", 2.0, 10);
var audi = new Car("audi", "Q7", 2008, "green", 4.0, 15);
var kia = new Car("kia", "Cerato", 2015, "blue", 1.8, 8);

console.log(bmw.serfiyyat(400));
console.log(audi.serfiyyat(400));
console.log(kia.serfiyyat(400));


