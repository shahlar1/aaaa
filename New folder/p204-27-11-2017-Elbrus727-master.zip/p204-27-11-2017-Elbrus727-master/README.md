# p204-27-11-2017

### Tapşırıq (JS - Video)

Bu videoya baxın. Object məntiqini çox yaxşı izah edir.
- https://www.youtube.com/watch?v=Bv_5Zv5c-Ts

*Sabaha qədər. Uğurlar.*
