// var user1 = { name: "Elbrus",surname: "Eliyev", "dogum_ili": 1991 }

// console.log(user1.dogum_ili);
// console.log(user1.name);

// var a = 5;
// var b = a;
// a = 10;

// console.log(b);

// var obj1 = { a: 30 }
// var obj2 = obj1;
// var obj3 = obj1;
// var obj4 = obj2;
// var obj5 = obj4;
// var obj6 = obj5;
// var obj7 = obj1;

// var obj6 = {a: 89};
// obj6 = obj1;

// obj4.a = 20;
// obj5.a = 30;


// var user1 = {
//     name: "Elbrus",
//     surname: "Eliyev"
// }

// var user2 = {
//     name: "Aqsin",
//     surname: "Huseynov"
// }

// // constructor
function User(name, surname, birthYear, password){
    
    // private properties
    var parol = password;
    var dogumIli = birthYear;
    var add =function(a,b){ //bu hisseni sonda Elnura izah ederken yazdim. Basa dusmeyen olsa, sabah bir de izah ederem
        return a+b;
    };

    // public properties and methods
    this.ad = name,
    // this.count = add(15,4), bu hisseni sonda Elnura izah ederken yazdim. Basa dusmeyen olsa, sabah bir de izah ederem
    this.soyad = surname,
    this.getFullName = function(){
        return this.ad + " " + this.soyad + " " + this.yas;
    },
    this.showHashedPassword = function(){
        var d = new Date();
        return parol+d.toString();
    },
    this.getAge = function(){
        var today = new Date();
        return today.getFullYear() - dogumIli;
    }
}

User.prototype.addGroup = function(x){
    this.groupName = x;
}


var user1 = new User("Elbrus", "Eliyev");
var user2 = new User("Aqsin", "Huseynov");
var user3 = new User("Aydan", "Yunus", 39);
var user4 = new User("Elnur", "Shahuseynli", 1997, "MC");

user4.addGroup("P204");

console.log(user3);

// slider constructor
// function Slider(selector){
//     var innerDivs = document.querySelectorAll(selector + " div");
//     this.numberDivs = function(){
//         return innerDivs.length;
//     }
// }

// var mySlider1 = new Slider(".main");
// console.log(mySlider1.numberDivs());

// var mySlider2 = new Slider(".slider2");
// console.log(mySlider2.numberDivs());

// Array.prototype.evveleArtir = function(n){
//     this.reverse();
//     this.push(n);
//     this.reverse();
// }

// var numbers = new Array();
// numbers.push(15);
// numbers.push(7);
// numbers.push(9);
// numbers.evveleArtir(2);

// var names = ["Elbrus", "Elnur", "Aydan"];
// names.evveleArtir("Efsane");

// console.log(names);

// String.prototype.numberOfVowels = function(){
//     var vowels = ["a", "i", "o", "u", "e"];
//     var count = 0;
//     for(var i = 0; i< this.length; i++){
//         if(vowels.indexOf(this[i].toLowerCase()) >= 0){
//             count++;
//         }
//     }
//     return count;
// }
