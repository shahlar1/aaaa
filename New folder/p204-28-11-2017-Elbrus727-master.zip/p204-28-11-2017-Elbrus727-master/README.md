# p204-28-11-2017

##### Dünən göndərdiyim videoya axıra kimi baxın. Bugün dərsdə yazdığım kodlara baxın, özünüz başa düşəsiniz deyə, bəzi əlavələr və dəyişiklər edərək effektlərini görün. Və aşağıdakıları sabah səhər tezdən kofe içə-içə ayıq başla oxuyun:
*- https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_Objects*

*Uğurlar. Sabaha qədər.*
