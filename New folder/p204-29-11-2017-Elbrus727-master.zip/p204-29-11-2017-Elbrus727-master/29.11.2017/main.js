
var slider1 = new Modal(".imagesDiv", { width: "50%", height: "50%", arrows: false });

var slider2 = new Modal(".list", { width: "75%", height: "75%" });

var pop1 = new Popover("ul li img");

slider1.hasOwnProperty("")

var a1 = document.querySelector('a:first-child');
var a2 = document.querySelector('a:last-child');

a1.modal("Modal title", "One fine body…");
a2.modal("Modal title 2", "One fine body 2…");

// (function add(a,b){
//     console.log(a+b)
// }(9,18))


// function sum(){
//     var sum = 0;
//     for(var i=0; i<arguments.length; i++){
//         if(typeof arguments[i] === "number")
//             sum+=arguments[i];
//     }
//     return sum;
// }

// console.log(sum("Elbrus",5,6,8,12,56,"Yene Ellbrus", 35,48, 65, 98, 78, 56, 78, 98, 5));

