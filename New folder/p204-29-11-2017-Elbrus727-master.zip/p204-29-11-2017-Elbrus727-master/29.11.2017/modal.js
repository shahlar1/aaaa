function Modal(selector){
    
        var defaults = {
            width: "95%",
            height: "95%",
            arrows: true
        }

        var userSettings = arguments[1] || {};

        var options = extend(defaults, userSettings);

        var wrapper = document.querySelector(selector);
        var allImages = document.querySelectorAll(selector + " img");
        
        for(var i = 0; i < allImages.length; i++){
            var img = allImages[i];
    
            img.addEventListener("click", function(e){
    
                this.classList.add("active");
    
                var modal = modalCreator();
                
                modal.style.backgroundImage = "url("+ this.getAttribute("src") +")";

                modal.style.width = options.width;
                modal.style.height = options.height;
    
                document.body.insertBefore(modal, wrapper.nextElementSibling);
    
                document.addEventListener("keydown", function(e){
                    if(e.keyCode == 27){
                        modal.remove();
                        var activeImg = document.querySelector('img.active');
                        activeImg.classList.remove("active");
                    }
                })
            })
        }
    
    
        function modalCreator(){
            var modal = document.createElement('div');
            modal.classList.add("modal");
            
            if(options.arrows){
                var leftArrow = document.createElement('i');
                leftArrow.classList.add("fa", "fa-angle-left");
        
                var rightArrow = document.createElement('i');
                rightArrow.classList.add("fa", "fa-angle-right");
        
                rightArrow.addEventListener("click", function(e){
                    var nextImg = changeImg("right");
                    modal.style.backgroundImage = "url("+ nextImg.getAttribute("src") +")";
                })
        
                leftArrow.addEventListener("click", function(e){
                    var nextImg = changeImg("left");
                    modal.style.backgroundImage = "url("+ nextImg.getAttribute("src") +")";
                })
        
                modal.appendChild(leftArrow);
                modal.appendChild(rightArrow);
            }
    
            return modal;
        }
    
        function changeImg(dir){
            var activeImg = document.querySelector('img.active');
            activeImg.classList.remove("active");
            if(dir == "right"){
                var nextLi = activeImg.parentElement.nextElementSibling || document.querySelector('ul li:first-child');
            }else if(dir == "left"){
                var nextLi = activeImg.parentElement.previousElementSibling || document.querySelector('ul li:last-child');
            }
            var nextImg = nextLi.children[0];
            nextImg.classList.add("active");
            
            return nextImg;
        }
    }

    function extend(defaults, additional){
        for(var key in additional){
            if(additional.hasOwnProperty(key)){
                defaults[key] = additional[key]
            }
        }
    
        return defaults;
    }