var modal = document.getElementById('simplemodal');
var modalBtn = document.getElementById('modalBtn');
var closeBtn = document.getElementsByClassName('closeBtn') [0];
var Btn = document.getElementsByClassName('Btn') [0];


modalBtn.addEventListener('click', openModal);

closeBtn.addEventListener('click', closeModal);

Btn.addEventListener('click', closeModal);


function openModal(){
    modal.style.display = 'block';

}


function closeModal(){
    modal.style.display = 'none';

}