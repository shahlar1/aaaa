# p204-29-11-2017

### Tapşırıq (JS)
- Yuxarıdakı homework.png-de görsənən formatda JS OOP ilə Modal yazmaq. Dərsdə yazdığımız koda yaxşı-yaxşı baxmağınız məsləhətdir.

*Uğurlar. Sabaha qədər.*
