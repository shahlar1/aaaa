$(document).ready(function(){
    // Bir nece ferqli event elave etmek ucun

    // $("button:first").on({
    //     click: function(){
    //         console.log('Buttona click edildi');
    //     },
    //     mouseenter: function(){
    //         console.log('Buttona hover edildi');
    //     },
    //     mouseleave: function(){
    //         console.log('Buttona hover cixildi');
    //     }
    // })

    // Hover event-ine giris ve cixis funksiaylarini elave etmek

    // $("button").hover(
    //     function(){
    //         $(this).css("backgroundColor", "blue")
    //     },
    //     function(){
    //         $(this).css("backgroundColor", "red")
    //     }
    // )

    // $("input").on({
    //     focus: function(){
    //         console.log('Input got focus');
    //     },
    //     blur: function(){
    //         console.log($(this).val());
    //     }
    // })
       
    // $("button[title='btn']").click(function(){
        // $("p.first").animate({
        //     left: "+=50px",
        //     background: "#ccc",
        //     top: "+=50px"
        // }, 3000, function(){ alert("animation bitdi") })

        // console.log($(this).text("Send").css("color", "red"));

        // console.log($(this).attr("class", "active"));

        // // $(this).html("<b>Hide</b>");
        // $("p.first")
        // .css("color", "red")
        // .click(function(){alert("clicked")})
        // .mouseover(function(){ console.log("mouse is over") })

    // })

    // $("button:not([title='btn'])").click(function(){
    //     $("p.first").stop();
    // })

    // var fButton = document.querySelector("button[title='btn']");

    // var span = document.createElement('span');
    // span.textContent = "Added";

    var span = $("<span>Added</span>");

    $("div").append(span).addClass("selected").removeClass("main");

    $("button").click(function(){
        console.log($("div").css({
            "height": "400px",
            "width": "250px",
            "color": "gray"
        }))
    })

    $("body").click(function (event) { 
        // var span = $("<span>x</span>");
        // $(span).css({
        //     "background": "#eee",
        //     "width": "100px",
        //     "height": "100px",
        //     "position": "absolute",
        //     "top": (event.pageY - 50) +"px",
        //     "left": (event.pageX - 50) +"px",
        //     "border-radius": "100%",

        // });

        // $("body").append(span);


    });

    // $("p").slick();

})
