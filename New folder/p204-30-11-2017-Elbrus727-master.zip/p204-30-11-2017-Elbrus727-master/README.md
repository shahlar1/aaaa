# p204-30-11-2017

### Tapşırıq (Jquery)
- w3schools-dan Jquery Traversing-e qeder olan butun movzulara baxin, her birini ozunuz yazin ve yoxlayin. 
- Bu linkde olan movzulara da baxin, burda bezi seyler var ki, w3-de yoxdur:
  https://www.tutorialspoint.com/jquery/jquery-dom.htm
- Əgər nəsə real bir tapşırıq yazmaq istəsəniz, indiyə qədər dərsdə yazdığımız və ya ev tapşırığı kimi verdiklərimi sıfırdan jquery ilə yazın. Bu şəkildə çox rahat öyrənə bilərsiniz. Məsələn, dərsdə yazdığımız hər 3 saniyədən bir fərqli rəngli və ölçülü div yaranmağı, dərsdə yazdığımız sadə və çətin slider, dairəvi və ya elektron saat, axırıncı dəfə evə verdiyim chat olan tapşırığı çalışın jquery yazmağa cəhd edin.

###### Sabaha hazır gəlin ki, yazacaqlarımı rahat başa düşə biləsiniz.

*Sabaha qədər. Uğurlar.*
