$(function(){


    // Jquery Flip plugin https://nnattawat.github.io/flip/

    // $(".card").flip({
    //     reverse: true,
    //     speed: 1200,
    //     front: ".main1",
    //     back: ".main2"
    // });

    // $(".card").on("flip:done", function(){
    //     alert("flip bitdi")
    // })

    // $(".mainSection").flip({
    //     axis: 'x',
    //     trigger: "hover"
    // });



    // Slick plugin starts here - http://kenwheeler.github.io/slick/

    // $(".wrapper").slick({
    //     dots: true,
    //     infinite: true,
    //     slidesToShow: 4,
    //     slidesToScroll: 1,
    //     arrows: true,
    //     speed: 600,
    //     autoplay: true,
    //     autoplaySpeed: 2000,
    //     responsive: [
    //         {
    //           breakpoint: 1024,
    //           settings: {
    //             slidesToShow: 3,
    //             slidesToScroll: 3,
    //             infinite: true,
    //             dots: true,
    //             arrows: true
    //           }
    //         },
    //         {
    //           breakpoint: 800,
    //           settings: {
    //             slidesToShow: 2,
    //             slidesToScroll: 2,
    //             arrows: true
    //           }
    //         },
    //         {
    //           breakpoint: 600,
    //           settings: {
    //             slidesToShow: 1,
    //             slidesToScroll: 1,
    //             arrows: false
    //           }
    //         }
    //         // You can unslick at a given breakpoint now by adding:
    //         // settings: "unslick"
    //         // instead of a settings object
    //       ]   
    // });

    // var filtered = false;
    
    // $('#filter').on('click', function(){
    //   if (filtered === false) {
    //     $('.wrapper').slick('slickFilter',':odd');
    //     $(this).text('Unfilter');
    //     filtered = true;
    //   } else {
    //     $('.wrapper').slick('slickUnfilter');
    //     $(this).text('Filter');
    //     filtered = false;
    //   }
    // });

    // Slick plugin ends

    


    // $("div").changeBg("rgb(45, 71, 221)");
    // $("a").changeBg("yellow");

    $("div").floatAnima({
        speed: 3000,
        distance: 700,
        trigger: "hover"
    });

    $("button").floatAnima({
        speed: 2000,
        distance: 900,
        trigger: "click"
    });


    var obj1 = {
        name: "Aqsin",
        surname: "Huseynov",
        age: 20
    }

    var obj2 = {
        name: "Perviz",
        age: 23
    }

    console.log(extend(obj1, obj2));

    function extend(object1, object2){
        for(var prop in object2){
            if(object2.hasOwnProperty(prop)){
                object1[prop] = object2[prop]
            }
        }

        return object1;
    }



    
})