(function ($) {

    $.fn.changeBg = function (color) {
        this.css("backgroundColor", color)
    }

    $.fn.floatAnima = function(options){

        var myDefaults = {
            speed: 1000,
            distance: 300,
            trigger: "click"
        }

        var settings = $.extend(myDefaults, options)

        if(settings.trigger === "hover")
            settings.trigger = "mouseover"

        this.on(settings.trigger, function(){
            $(this).css("position","relative")
            .animate({
                left: "+="+settings.distance+"px",
            }, settings.speed, function(){
                $(this).animate({
                    left: "0px"
                }, settings.speed)
            })
        })
    }

}(jQuery))