$ ( ".card" ).flip ({ 
    axis : 'y' , 
    reverse : true }); 

$(".card").on('flip:done', function(){
    $(this).next().flip('toggle')
})