# p204-05-12-2017

##### Tapşırıq (jQuery)

- Flip plugin-inden istifadə etməlisiniz. 15 ədəd kiçik ölçüdə div (kart) olmalıdır. Hər birinin front hissəsi birrəngli olmalıdır və hamısı eyni rəngdə olmalıdır. Hər birinin back hissəsi isə şəkil olmalıdır. User hər hansısa birinin üzərinə click etdikdə, həmin kartın back hissəsi görsənməli, bir neçə saniyə sonra yenidən front-u görsənməlidir və həmin kartdan sonra gələn bütün kartlar bir-bir ardıcıllıqla bu şəkildə davam etməlidir. Yəni hər bir növbəti kartın back-i görsənməli, bir saniyə sonra yenidən front-u görsənməlidir. Və bu ardıcıllıqla getməlidir. Ta ki, axırıncı karta çatana qədər. Bildiyiniz domino effekti kimi bir şey.

- JQuery Plugin yazacaqsınız. Hansı elementlər seçiləcəksə, həmin element-lərin width və height-ını 2 dəfə artıraraq, div-i dairəvi edərək və background-color-unu dəyişib, yenidən əvvəlki vəziyyətinə qaytarmalıdır. Bunların hamısını animation ilə etməlidir. Və neçə dəfə artırılma və rəng user tərəfindən də funksiyaya verilə bilməlidir.

Sabah saat 2-ə qədər vaxtınız var.

*Sabaha qədər. Uğurlar.*
