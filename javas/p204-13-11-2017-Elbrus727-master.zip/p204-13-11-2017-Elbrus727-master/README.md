# p204-13-11-2017

Dərsdə yazdığımız bütün tapşırıqlara evdə baxın.

### Tapşırıq (Grid system - Oxumaq)
- Aşağıdakı linki hamı başdan-ayağa oxusun. Sabah dərsdə sual-cavab olacaq.
https://www.sitepoint.com/understanding-css-grid-systems/

### Tapşırıq (CSS Animation - Oxumaq)
- Tapşırıq vermirəm, çünki aşağıdakı linkdə həm 7-8 dənə tapşırıq həll olunur, həm də gözəl izah edilir. Hamısına baxın, istəyən onları özü üçün yazsın (koda baxmadan). Bu halda çox şey öyrənmiş olacaqsınız.
https://robots.thoughtbot.com/css-animation-for-beginners

*Uğurlar. Sabaha qədər.*
