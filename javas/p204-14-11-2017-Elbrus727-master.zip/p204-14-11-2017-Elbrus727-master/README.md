# p204-14-11-2017

### Tapşırıq (HTML)
- Homework.png template-ni responsive olaraq yazmalısınız. 700x300 yazılan div-lər və onların altındakı uyğun yazılar tablet və mobile-da hər biri ayrı-ayrı görsənməlidir, yəni yanbayan yox alt-alta. Sabah saat 2-ə qədər vaxtınız var.

P.S. Məsləhət görürəm ki, keçən dəfə bu template-də sizə yazdığım issue-a baxasınız və ordakı səhvləri təkrarlamayasınız.

#### Videonu da Google Drive-a yüklədim. Aşağıdakı linkdən baxa bilərsiniz:
- https://drive.google.com/drive/folders/1bqqDWjObCnMJImrP_iAmRRF5y-2bPESr

*Uğurlar. Sabaha qədər.*
