document.querySelector("body").addEventListener("click", function(){
    // alert("Body is clicked");
    document.querySelector(".mainH").innerHTML = "Changed";
    // document.write("<h1>Hello, World!</h1>");
})

// console.log("Hello world");
// console.log("It is me");


// var x = 5, name = "P204 McDonald's dayiq";
// console.log(x);

// if(x>3){
//     x = true;
// }else{
//     x= false;
// }
// console.log(x);

// console.log(z);
// var z;
// console.log(z);
// z=15;
// console.log(z);
// z=16;
// console.log(z);


// var n1 = 5;
// var n2 = "5";
// console.log(n1 === n2);

// var x = 15;
// var y = 17;
// var z = 23;

// console.log(y && x && z);

var name = "Aqsin";

var userInput = "Samir";

name = userInput || name;

console.log(name);