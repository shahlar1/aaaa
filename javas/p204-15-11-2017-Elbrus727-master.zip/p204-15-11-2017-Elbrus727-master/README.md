# p204-15-11-2017

### Tapşırıq
W3schools-dan "Javascript Data Types"-a qədər olan hamısına baxın və hər bir şeyi diqqətlə, özünüz yaza-yaza oxuyun. Bundan əlavə, emailə attach etdiyim kitaba (Eloquent Javascript) başlayın.



