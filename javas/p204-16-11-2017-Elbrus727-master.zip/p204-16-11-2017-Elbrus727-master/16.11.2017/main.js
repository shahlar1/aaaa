// ARRAYS

// var names = [ "Huseyn", "Elbrus", "Aydan","Elbrus", "Efsane", "Elnur", "Elbrus", "Samir", "Elbrus" ];
// var names2 = ["Arif", "Kenan"];
// var names3 = ["Vusal", "Vuqar"];

// while(names.length < 10){
//     var newUser = prompt("Adinizi daxil edin: ");
//     names.push(newUser);
//     console.log(names);
// }
// console.log("Artiq array-de yer yoxdur");

// console.log('Sirada 1-ci: ' + names[0]);
// console.log('Sirada 2-ci: ' + names[1]);



// for(var i=0; i < names.length; i++){
//     console.log("Sirada " + (i+1) + "-ci: " + names[i] + "-dir.");
// }

// var leftPart = names.slice(0, 3);
// var rightPart = names.slice(4);
// var mergedNames = leftPart.concat(rightPart);
// console.log(mergedNames);   

// names = names.concat(names2, names3);

// console.log(names);
// var leftPart = names.slice(0, 3);
// var rightPart = names.slice(3);
// var newUser = "Memmed";
// rightPart.unshift(newUser);
// names = leftPart.concat(rightPart);
// console.log(names);
// names.sort();
// console.log(names);
// names.reverse();
// console.log(names);

// var name = ["Namiq", "Vuqar"];
// console.log(name.slice(0,2));

// var indexes = "";
// for(var i = 0; i<=names.length; i++){
//     if(names[i] == "Elbrus"){
//         indexes += i + ", ";
//     }
// }
// console.log(indexes);


// OBJECTS 

// var student = {
//     name: "Arif",
//     surname: "Meherremov",
//     email: "arif.m@code.edu.az",
//     occupation: "student"
// }

// console.log(typeof student); 


// Functions

// var surname = "Meherremov";
// var count = 5;

// for(var i=0; i<count; i++){
//     console.log((i+1), surname );
// }

// surname = "Eliyev";
// count = 7;
// for(var i=0; i<count; i++){
//     console.log((i+1), surname );
// }

// surname = "Elili";
// count = 7;
// for(var i=0; i<count; i++){
//     console.log((i+1), surname );
// }

// function repeatWord(word, repeatCount){
//     for(var i=0; i<repeatCount; i++){
//         console.log((i+1), word );
//     }
// }

// repeatWord("Meherremov", 5);
// repeatWord("Eliyev", 7);
// repeatWord("Hesenov", 10);

function power(base, p){
    var result = 1;
    p = p || 1;
    for(var i =0; i < p; i++){
        result = result * base;
    }
    return result;
}

// var a = power(5,3);
alert(power(5,5));



var numbers = [5,6,9,12,12];

var cem = sum(numbers);

console.log(cem);

function sum(myArray){

    return cem;
}