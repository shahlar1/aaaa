# p204-16-11-2017

### Tapşırıq (Oxumaq - JS)
- https://www.w3schools.com/js/js_string_methods.asp
- https://www.w3schools.com/js/js_number_methods.asp
- https://www.w3schools.com/js/js_array_methods.asp

### Tapşırıq (Funksiya - JS)
- Bir funksiya yazmalısınız. Funksiya bir parametr qəbul edəcək və bu parametr-in tipi array olacaq. Funksiya array-in daxilindəki hər bir rəqəmin tək və ya cüt olduğunu console-a yazdırmalıdır.
- Bir funksiya yazmalısınız. Funksiya bir parametr qəbul edəcək və bu parametr-in tipi array olacaq. Funksiya bu array-in daxilindəki hər bir bir sözə baxacaq, əgər sözün uzunluğu 5-dən böyükdürsə, onu console-a yazdıracaq.

Tapşırıqları həll etmək üçün yuxarıda verilən linklərdəki String və Array-ə aid olan hissələri yaxşı oxumalısınız. Bütün funksiyalara baxın və hamısını özünüz yazın.

*Sabaha qədər. Uğurlar.*
