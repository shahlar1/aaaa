var names = ["Elnur", "Efsane", "Arif", "Kenan", "Samir", "Ceyhun", "Aydan", "Elmir", "Eli", "Elbrus"];
var soyadlar = ["Almazzade", "Nadirova", "Meherremov", "Ehmedov"];
var email = ["almaz@code.edu.az", "nadir@code.az", "meherrem@code.az", "ehmed@code.az"];


// for(var i = 0; i < adlar.length; i++){
//     // console.log(adlar[i], "sozunun uzunlugu", adlar[i].length,"herflidir."); 
//     if(adlar[i].length > 5){
//         console.log(adlar[i], "adi 5-den uzundur.");
//     }else{
//         console.log(adlar[i], "adi 5-den uzun deyil.");
//     }
// }

// console.log('Adlar bitdi.');
// console.log('----------------------------------');
// console.log('');

// for(var i = 0; i < soyadlar.length; i++){
//     if(soyadlar[i].length > 5){
//         console.log(soyadlar[i], "soyadi 5-den uzundur.");
//     }else{
//         console.log(soyadlar[i], "soyadi 5-den uzun deyil.");
//     }
// }

// console.log('Soyadlar bitdi.');

// for(var i = 0; i < email.length; i++){
//     if(email[i].length > 5){
//         console.log(email[i], "soyadi 5-den uzundur.");
//     }else{
//         console.log(email[i], "soyadi 5-den uzun deyil.");
//     }
// }

// console.log('Soyadlar bitdi.');

// function arrayYazdir(array){
//     for(var i = 0; i < array.length; i++){
//         if(array[i].length > 5){
//             console.log(array[i], "sozu 5-den boyukdur.");
//         }else{
//             console.log(array[i], "sozu 5-den kicikdir.");
//         }
//     }

//     console.log("Loop is over");
//     console.log("---------------------");
// }
// arrayYazdir(soyadlar);
// arrayYazdir(names);
// arrayYazdir(email);


// var number = 5;

// function goster(){
//     var number = 15;
//     console.log(number);
// }

// goster();



// Yazdir funksiyasi
// function yazdir(name){
//     console.log(name.length);
// }

// yazdir("Samir");
// yazdir("Elbrus");
// yazdir("Arif");
// yazdir("Kenan");



// Sozdeki herfler
// Ilk herf

// function ilkHerf(myArray){
//     for(var i = 0; i < myArray.length; i++){
//         console.log(myArray[i],"sozunun ilk herfi", myArray[i][0]);
//     }
// }

// ilkHerf(names);

// Sozdeki herfler
// Butun herfler

// function butunHerfler(myArray){
//     for(var i = 0; i < myArray.length; i++){
//         console.log(myArray[i]);
//         for(var j = 0; j < myArray[i].length; j++ ){
//             console.log((j+1) + "-ci herf "+ myArray[i][j]);
//         }
//     }
//     console.log('Butun sozlerdeki herfler yazildi');
// }

// butunHerfler(names);


// Sozdeki saitler

// var saitler = ["a", "e", "i", "o", "u"];

// function sozdekiSaitler(myArray) {
//     for (var i = 0; i < myArray.length; i++) {
//         // console.log(myArray[i]);
//         var selectedWord = myArray[i];
//         for (var j = 0; j < myArray[i].length; j++) {
//             var countOfVowel = 0;
//             if(saitler.indexOf(selectedWord[j].toLowerCase()) != -1){
//                 // console.log(selectedWord + " sozunde " + selectedWord[j] + " saiti var.");
//                 countOfVowel++;
//             }
//         }
//         console.log(selectedWord + " sozunde " + countOfVowel + " sayda sait var");
//     }
//     console.log('Butun sozlerdeki herfler yazildi');
// }
// sozdekiSaitler(names);
