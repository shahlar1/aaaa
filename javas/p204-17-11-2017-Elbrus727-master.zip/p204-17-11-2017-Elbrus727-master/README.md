# p204-17-11-2017

### Tapşırıq (Oxumaq - JS)
Aşağıdakı linkə axıra qədər baxın və yalnız baxmayın. Orda verilən kodları özünüz dəyişin, özünüz yazın. Dərsdə onların əksəriyyətini lazım olduqca istifadə edəcəyik.
- https://www.w3schools.com/js/js_htmldom.asp

### Tapşırıq (JS)
HTML faylında script-dən başqa heç bir HTML tagi olmamalıdır. Javascriptdə bir funksiya yazmalısınız. Həmin funksiya parametr olaraq bir rəqəm qəbul edəcək. Və həmin sayda div yaradaraq html-də body-ə əlavə edəcək. Div-lərin daxilində bir şəkil olacaq, şəkillərin altında da bir p tag-i olacaq. Şəkillərin hamısının src attribute-u eyni şəkil ola bilər. Div-lər yanbayan düşməlidir. Yaratdığınız funksiyaya və bütün variable-lara düzgün və anlaşıqlı adlar verməyiniz tövsiyə olunandır.
(Bütün CSS property-lərini (div-lərin dizaynını) özünüz verə bilərsiniz. Nə qədər səliqəli olarsa, bir o qədər balınıza təsiri müsbət olacaq ;) ).

### Tapşırıq (template)
Yuxarıdakı "homeworkAirTemplate.jpg" template-ni bitirməlisiniz. HTML strukturuna və saytın səliqəli olmasına diqqət edin.

Həftənin 1-ci günü (20 Noyabr) saat 2-ə qədər vaxtınız var.
Tapşırıqları yükləyərkən hər bir tapşırığın ayrı-ayrı folder-in içərisində olmağına diqqət yetirin.

*Sizə möhtəşəm həftəsonu arzu edirəm. :D Sabah lab-da görüşərik. Uğurlar.*



