// var mainDiv = document.querySelector('#main')

// var div = document.createElement('div');
// var button = document.createElement('button');
// button.classList.add("btn");
// button.textContent = "Change color";

// var buttonReset = document.createElement('button');
// buttonReset.textContent = "Reset counter";


// var buttonClickCount = 1;

// button.addEventListener("click", function(){
//     console.log('Button-a ' + buttonClickCount +  ' defe click olundu');
//     buttonClickCount++;
// })

// buttonReset.addEventListener("click", function(){
//     buttonClickCount = 1;
// })

// mainDiv.appendChild(div);
// mainDiv.appendChild(button);
// mainDiv.appendChild(buttonReset);


function coloredDivCreator(count){
    for(var i=0; i < count; i++){
        var span = document.createElement('span');
        var randomColor = colors[Math.floor(Math.random()*(colors.length-1))];
        span.style.backgroundColor = randomColor;
        span.classList.add("coloredDiv");
        span.addEventListener("click", function(){
             selectedColor =  this.style.backgroundColor;
             result.style.backgroundColor = selectedColor;
        })

        coloredDivsHolder.appendChild(span);
    }
}

var mainDiv = document.querySelector('#main')
var colors = ["AliceBlue","AntiqueWhite","Aqua","Aquamarine","Azure","Beige","Bisque","Black","BlanchedAlmond","Blue","BlueViolet","Brown","BurlyWood","CadetBlue","Chartreuse","Chocolate","Coral","CornflowerBlue","Cornsilk","Crimson","Cyan","DarkBlue","DarkCyan","DarkGoldenRod","DarkGray","DarkGrey","DarkGreen","DarkKhaki","DarkMagenta","DarkOliveGreen","Darkorange","DarkOrchid","DarkRed","DarkSalmon","DarkSeaGreen","DarkSlateBlue","DarkSlateGray","DarkSlateGrey","DarkTurquoise","DarkViolet","DeepPink","DeepSkyBlue","DimGray","DimGrey","DodgerBlue","FireBrick","FloralWhite","ForestGreen","Fuchsia","Gainsboro","GhostWhite","Gold","GoldenRod","Gray","Grey","Green","GreenYellow","HoneyDew","HotPink","IndianRed","Indigo","Ivory","Khaki","Lavender","LavenderBlush","LawnGreen","LemonChiffon","LightBlue","LightCoral","LightCyan","LightGoldenRodYellow","LightGray","LightGrey","LightGreen","LightPink","LightSalmon","LightSeaGreen","LightSkyBlue","LightSlateGray","LightSlateGrey","LightSteelBlue","LightYellow","Lime","LimeGreen","Linen","Magenta","Maroon","MediumAquaMarine","MediumBlue","MediumOrchid","MediumPurple","MediumSeaGreen","MediumSlateBlue","MediumSpringGreen","MediumTurquoise","MediumVioletRed","MidnightBlue","MintCream","MistyRose","Moccasin","NavajoWhite","Navy","OldLace","Olive","OliveDrab","Orange","OrangeRed","Orchid","PaleGoldenRod","PaleGreen","PaleTurquoise","PaleVioletRed","PapayaWhip","PeachPuff","Peru","Pink","Plum","PowderBlue","Purple","Red","RosyBrown","RoyalBlue","SaddleBrown","Salmon","SandyBrown","SeaGreen","SeaShell","Sienna","Silver","SkyBlue","SlateBlue","SlateGray","SlateGrey","Snow","SpringGreen","SteelBlue","Tan","Teal","Thistle","Tomato","Turquoise","Violet","Wheat","White","WhiteSmoke","Yellow","YellowGreen"];

var coloredDivsHolder = document.createElement('div');
coloredDivCreator(150);
coloredDivsHolder.classList.add("coloredDivsHolder");
mainDiv.appendChild(coloredDivsHolder);

var result = document.createElement('div');
result.classList.add("result");
mainDiv.appendChild(result);


var input = document.createElement('input');
input.setAttribute("type", "number");
input.setAttribute("min", "200");
input.addEventListener("change", function(){
    var number = Number(this.value);
    result.style.width = number+"px";
    result.style.height = number+"px";
})
mainDiv.appendChild(input);

