var images = ["1.jpg","2.jpg", "3.jpg", "4.jpg", "5.png"];


function divCreator(count){
    for(var i=0; i<count; i++){
        var mainDiv = document.createElement('div');
        mainDiv.classList.add("mainDivs");
        
        var imageHolder = document.createElement('div');
        imageHolder.classList.add("imageHolder");

        // random image selector
        var src = images[Math.floor(Math.random()*(images.length-1))];

        imageHolder.style.backgroundImage = "url("+src+")";

        var text = document.createElement('p');
        text.textContent = "Hi, there. Today is my and Samir's birthday!";
        text.classList.add("text");

        mainDiv.appendChild(imageHolder);
        mainDiv.appendChild(text);

        document.body.appendChild(mainDiv);
    }
}

var userInput = Number(prompt("Divlerin ve tepegozlerin sayini daxil edin: "));
divCreator(userInput);
