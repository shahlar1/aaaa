# P204-20.11.2017

### Tapşırıq (JS)
- Tapşırığı wp qrupa yazacam. )

*Sabaha qədər. Uğurlar.*
