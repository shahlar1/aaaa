// var main = document.querySelector('#main');
// Mousemove colored spans

// var widthHeight = 30;
// var colors = ["AliceBlue","AntiqueWhite","Aqua","Aquamarine","Azure","Beige","Bisque","Black","BlanchedAlmond","Blue","BlueViolet","Brown","BurlyWood","CadetBlue","Chartreuse","Chocolate","Coral","CornflowerBlue","Cornsilk","Crimson","Cyan","DarkBlue","DarkCyan","DarkGoldenRod","DarkGray","DarkGrey","DarkGreen","DarkKhaki","DarkMagenta","DarkOliveGreen","Darkorange","DarkOrchid","DarkRed","DarkSalmon","DarkSeaGreen","DarkSlateBlue","DarkSlateGray","DarkSlateGrey","DarkTurquoise","DarkViolet","DeepPink","DeepSkyBlue","DimGray","DimGrey","DodgerBlue","FireBrick","FloralWhite","ForestGreen","Fuchsia","Gainsboro","GhostWhite","Gold","GoldenRod","Gray","Grey","Green","GreenYellow","HoneyDew","HotPink","IndianRed","Indigo","Ivory","Khaki","Lavender","LavenderBlush","LawnGreen","LemonChiffon","LightBlue","LightCoral","LightCyan","LightGoldenRodYellow","LightGray","LightGrey","LightGreen","LightPink","LightSalmon","LightSeaGreen","LightSkyBlue","LightSlateGray","LightSlateGrey","LightSteelBlue","LightYellow","Lime","LimeGreen","Linen","Magenta","Maroon","MediumAquaMarine","MediumBlue","MediumOrchid","MediumPurple","MediumSeaGreen","MediumSlateBlue","MediumSpringGreen","MediumTurquoise","MediumVioletRed","MidnightBlue","MintCream","MistyRose","Moccasin","NavajoWhite","Navy","OldLace","Olive","OliveDrab","Orange","OrangeRed","Orchid","PaleGoldenRod","PaleGreen","PaleTurquoise","PaleVioletRed","PapayaWhip","PeachPuff","Peru","Pink","Plum","PowderBlue","Purple","Red","RosyBrown","RoyalBlue","SaddleBrown","Salmon","SandyBrown","SeaGreen","SeaShell","Sienna","Silver","SkyBlue","SlateBlue","SlateGray","SlateGrey","Snow","SpringGreen","SteelBlue","Tan","Teal","Thistle","Tomato","Turquoise","Violet","Wheat","White","WhiteSmoke","Yellow","YellowGreen"];
// var record = 0;
// var recordSpan = document.querySelector('#record');

// recordSpan.textContent = "Not recording.";

// function randomColorGenerator(){
//     var id = Math.floor(Math.random()*(colors.length-1));
//     var color = colors[id];
//     return color;
// }

// document.addEventListener("click", function(){
//     record = 1- record;
//     if(record){
//         recordSpan.style.backgroundColor = "rgb(17, 109, 37)";
//         recordSpan.textContent = "On Air.";
//     }else{
//         recordSpan.style.backgroundColor = "rgb(90, 24, 24)";
//         recordSpan.textContent = "Not recording.";
//     }
    
// })

// document.addEventListener("mousemove", function(e){
//     if(record){
//         var top = e.pageY;
//         var left = e.pageX;
    
//         var span = document.createElement('span');
//         span.style.width = widthHeight + "px";
//         span.style.height = widthHeight + "px";
//         span.style.top = (top-widthHeight/2) + "px";
//         span.style.left = (left-widthHeight/2) + "px";
//         span.style.background = randomColorGenerator();
    
//         main.appendChild(span);
//     }
    
// })









// Password checker

// var passwordInput = document.querySelector('input[type=password]');
// var feedback = document.querySelector('#feedback');

// passwordInput.addEventListener("keydown", function(){
//     if(this.value.length < 8){
//         feedback.textContent = "Weak";
//         feedback.style.color = "rgb(90, 24, 24)";
//         feedback.style.fontWeight = "bold";
//     }else{
//         feedback.textContent = "Strong";
//         feedback.style.color = "rgb(17, 109, 37)";
//         feedback.style.fontWeight = "bold";
//     }
// })

// passwordInput.addEventListener("blur", function(){
//     console.log('Input lost  focus');
// })

// link <a> prevent default
// var link = document.querySelector('a');
// link.addEventListener("click", function(){
//     event.preventDefault();
//     this.style.color = "red";
// })








// Context menu, mouse right click, mouse double click

// var main = document.querySelector('#main');
// var cntMenu = document.querySelector('#contextMenu');

// main.addEventListener("mouseover", function(){
//     this.classList.remove("default");
//     this.classList.add("active", "main");
// })

// main.addEventListener("mouseout", function(){
//     this.classList.remove("active", "main");
//     this.classList.add("default");
// })

// main.addEventListener("contextmenu", function(){
//     alert("right click clicked")
// })

// document.addEventListener("contextmenu", function(event){
//     event.preventDefault();
//     cntMenu.style.top = event.pageY + "px";
//     cntMenu.style.left = event.pageX + "px";
//     cntMenu.style.display = "block";
// })

// document.addEventListener("click", function(event){
//     cntMenu.style.display == "block" ? cntMenu.style.display = "none" : "";
// })