var textInput = document.querySelector('input');
var submitButton = document.querySelector('button');
var mainDiv = document.querySelector('#main')
var saygac = 1;

submitButton.addEventListener("click", function(){
    mainDiv.innerHTML = "";
    var inputValue = textInput.value;
    for(var i = 0; i < inputValue; i++){
        var demoDiv = document.createElement('div');
        demoDiv.classList.add("divs");
        demoDiv.id = "div"+(i+1);

        demoDiv.addEventListener('click',function(e){
            this.remove();
            alert("Siz artiq " + saygac + " dene div silmisiniz. Sildiyiniz div-in ID-si " + e.target.id);
            saygac++;
        })

        mainDiv.appendChild(demoDiv);
    }
})