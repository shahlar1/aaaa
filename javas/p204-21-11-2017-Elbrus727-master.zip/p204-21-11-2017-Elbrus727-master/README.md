# p204-21-11-2017


### Tapşırıq (JS - oxumaq)
- https://www.w3schools.com/jsref/dom_obj_event.asp

### Tapşırıq (JS - araşdırma)
Aşağıdakı sualları araşdırıb hər biri haqqında bir word fayla yazıb, yüklənməlidir.
1. Mouseover ile mouseenter arasında fərq nələrdir?
2. Event bubbling ile event capturing nədir? Oxumaq üçün link: https://javascript.info/bubbling-and-capturing
3. Mouseevent-lərlə Keyboardevent-lər arasındakı fərqlər nələrdir. Onlarda funksiyanın daxilində istifadə etdiyimiz "event" obyekti arasında fərqlər nədir?
4. OffsetHeight və OffsetWidth nədir?
5. ScrollLeft və ScrollTop nədir?

Ətraflı oxuyun və haqqında ətraflı yazın. Dərsdə bunlara aid nəsə yazmağa çalışacağıq.

*Sabaha qədər. Uğurlar.*
