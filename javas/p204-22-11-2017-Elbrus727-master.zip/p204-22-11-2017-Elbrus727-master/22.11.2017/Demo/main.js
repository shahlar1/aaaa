var wrapperDiv = document.querySelector('.wrapper');
var childDiv = wrapperDiv.children[0];
var headerDiv = wrapperDiv.previousElementSibling;

wrapperDiv.addEventListener("mouseover", function(){
    this.style.backgroundColor = "yellow";
})

wrapperDiv.addEventListener("mouseout", function(){
    this.style.backgroundColor = "";
})

childDiv.addEventListener("mouseover", function(){
    // event.stopPropagation();
    this.style.backgroundColor = "blue";
})

childDiv.addEventListener("mouseout", function(){
    this.style.backgroundColor = "";
})

document.addEventListener("keydown", function(event){
    if(event.keyCode == 27){
        wrapperDiv.style.display = "none";
    }else if( event.keyCode == 77 && event.ctrlKey && event.altKey){
        wrapperDiv.style.display = "block";
    }
})

document.addEventListener("scroll", function(){
    if(window.scrollY > 50){
        headerDiv.style.position = "fixed";
        headerDiv.style.top = "0";
        headerDiv.style.left = "0";
    }else{
        headerDiv.style.position = "static";
        
    }
})
