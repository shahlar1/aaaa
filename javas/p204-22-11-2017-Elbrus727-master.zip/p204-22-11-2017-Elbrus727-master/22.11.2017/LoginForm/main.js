var loginButton = document.querySelector('.login'),
    layout = loginButton.nextElementSibling,
    submitButton = document.querySelector('a.submit'),
    username = document.querySelector('#username'),
    usernameError = username.nextElementSibling,
    password = document.querySelector('#password'),
    passwordError = password.nextElementSibling,
    welcomeDiv = document.querySelector('.welcome');

loginButton.addEventListener("click", function(event){
    layout.style.display = "block";
    // if(event.ctrlKey){
    //     console.log('Ctrl and mouse clicked');
    // }
    // var parentWidth = layout.offsetWidth;
    // var parentHeight = layout.offsetHeight;
    // var loginWidth = layout.children[0].offsetWidth;
    // var loginHeight = layout.children[0].offsetHeight;
    // layout.children[0].style.top = ((parentHeight-loginHeight)/2) + "px";
    // layout.children[0].style.left = (parentWidth-loginWidth)/2 + "px";
    // console.log(parentHeight,loginHeight );
})

layout.addEventListener("click", function(event){
    if(event.target.classList.contains("layout")){
        this.style.display = "none";
    }
})

document.addEventListener("keydown", function(event){
    if(event.keyCode == 27){
        if(layout.style.display == "block"){
            layout.style.display = "none";
        }
    }
})

submitButton.addEventListener("click", function(event){
    event.preventDefault();
    var errorName = false;
    var errorPass = false;

    if(username.value === "Elbrus"){
        errorName = false;
        usernameError.textContent = "";
    }else {
        errorName = true;
        if(username.value === ""){
            usernameError.textContent = "Username bos buraxila bilmez.";
        }else{
            usernameError.textContent = "Username sehvdir."
        }
    }

    if(password.value === ""){
        errorPass = true;
        passwordError.textContent = "Password bos buraxila bilmez.";
    }else if(password.value !== "123"){
        errorPass = true;
        passwordError.textContent = "Password sehvdir."
    }else{
        errorPass = false;
        passwordError.textContent = "";
    }

    if(!errorPass && !errorName){
        alert("Siz sisteme ugurla daxil oldunuz.");
        layout.style.display = "none";
        loginButton.style.display = "none";
        welcomeDiv.children[0].textContent = username.value+ ", xos gelmisiniz!";
        welcomeDiv.style.display = "block";
    }
})