# p204-22-11-2017

### Tapşırıq (JS kod)
- Dərsdə yazdığımız və bura yüklədiyim kodun üzərində işləyin. Login button-unun yanına bir də Register button-u əlavə edirsiniz. Və onun üzərinə click edəndə Registration form açılamlıdır. Eynilə mənim dərsdə yazdığım funksionallıqlar orda olmalıdır. Yəni formun ətrafında harasa click edildikdə və ya Esc düyməsi basıldıqda form bağlanmalıdır. Lakin login formdan fərqli olaraq registration form-da aşağıdakılar olmalıdır:
1) User-in adı, boş ola bilməz;
2) User-in soyadı, boş ola bilməz;
3) User-in username, boş ola bilməz, rəqəmlə başlaya bilməz;
4) User-in password-u, boş ola bilməz, minimum 8 xarakter uzunluğunda olmalıdır;
5) Repeat password, yəni parolu təkrar girmək üçün olan yer. Yazılan password-a bərabər olmalıdır.

Bunların hər birini düzgün yazan user-ə bir alert ilə uğurla qeydiyyatdan keçdiyi bildirilməlidir. Səhv yazdığı halda uyğun label-larla error göstərilməlidir. 

Çalışın yazdığım kodu copy/paste etmədən özünüz yazasınız. Lazım gələrsə, baxmağınız tövsiyə olunur.

Sabah saat 2-ə qədər vaxtınız var. 

*Sabaha qədər. Uğurlar.*
