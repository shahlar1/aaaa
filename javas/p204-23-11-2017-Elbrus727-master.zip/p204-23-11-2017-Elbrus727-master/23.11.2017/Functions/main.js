window.addEventListener("load", function(){
    
    // console.log(reqem);
    // console.log(eded);
    // var eded = 37;
    // console.log(eded);
    
   

    // console.log(result);
    // var result = add(1, 25);
    // console.log(result);
    
    // function hesab(){
    //     var result;
    //     switch (arguments[0]) {
    //         case "+":
    //             result = 0;
    //             for(var i=1; i<arguments.length; i++){
    //                 result+=arguments[i];
    //             }
    //             break;

    //         case "*":
    //             result = 1;
    //             for(var i=1; i<arguments.length; i++){
    //                 result*=arguments[i];
    //             }
    //             break;

    //         case "-":
    //             result = 0;
    //             for(var i=1; i<arguments.length; i++){
    //                 result-=arguments[i];
    //             }
    //             break;
    //         default:
    //             result = "Toplama, cixma ve ya vurmani secmelisiniz.";
    //             break;
    //     }

    //     return result;
    // }

    // console.log(hesab("*",5,10,15,30,65, 154, 165));

    // function add(a, b = 0){
    //     return a+b;
    // }

    // console.log(add(15));


    

})