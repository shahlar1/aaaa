var submitButton = document.querySelector('#submit');
var enterButton = document.querySelector('#enter');
var inputUsername = document.querySelector('#username');
var inputFirstname = document.querySelector('#firstname');
var firstNameError = inputFirstname.nextElementSibling;

var numbers = ["0", "1", "2", "3", "4"];

function onClick(event){
    event.target.nextElementSibling.textContent = event.target.textContent;
}

submitButton.addEventListener("click", function(event){
    onClick(event);
});
enterButton.addEventListener("click", function(event){
    onClick(event);
});

// inputFirstname.classList.toggle("first");
// inputFirstname.classList.toggle("center");
// console.log(inputFirstname.classList.contains("redasdads"));
// console.log(inputFirstname.classList);  

// firstNameError.textContent = "Hello";
// console.log(firstNameError.textContent);

// submitButton.addEventListener("click", function(event){
    // var firstLetterUsername = inputUsername.value[0]; 
    // var firstLetterFirstname = inputFirstname.value[0]; 

//     if(isNumber(inputUsername)){
//         console.log('Username-in ilk herfi reqemdir');
//     }
//     if(isNumber(inputFirstname)){
//         firstNameError.style.display = "inline";
//     }
// })

// function isNumber(letter){
//     for(var i = 0; i < numbers.length; i++){
//         if(numbers[i] == letter){
//             return true;
//         }
//     }
// }

// function isNumberAdv(word){
//     if(word.charCodeAt(0)>=48 && word.charCodeAt(0)<=57){
//         console.log("Reqemdir");
//     }
// }
