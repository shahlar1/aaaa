window.addEventListener("load", function () {

    var overflow = document.querySelector('.overflow');
    var leftAr = document.querySelector('.leftArrow');
    var rightAr = document.querySelector('.rightArrow');
    var overflowAfter = document.querySelector('.wrapper .after');
    var overflowBefore= document.querySelector('.wrapper .before');
    var listItems = document.querySelectorAll('.listItem');

    var index = 0;
    var count = overflow.children.length;

    rightAr.addEventListener("click", function () {
        change("right");
    })
    leftAr.addEventListener("click", function () {
        change("left");
    })

    document.addEventListener("keydown", function(e){
        if(e.keyCode == 39){
            change("right");
        }else if(e.keyCode == 37){
            change("left");
        }
    })

    overflowAfter.addEventListener("click", function(){
        change("right");
    })
    overflowBefore.addEventListener("click", function(){
        change("left");
    })

    function change(dir) {
        if (dir == "right") {
            if (index == count - 1) {
                index = 0;
            } else {
                index++;
            }
        } else if (dir == "left") {
            if (index == 0) {
                index = count - 1;
            } else {
                index--;
            }
        }

        var left = -index * 800;
        overflow.style.left = left + "px";
    }


    // Bottom list divs

    for(var i = 0; i < listItems.length; i++){
        var element = listItems[i];
        element.addEventListener("click", function(e){
            var activeElement = document.querySelector('.listItem.active');
            e.target.classList.add("active");
            activeElement.classList.remove("active");
            var elementIndex = Array.prototype.indexOf.call(listItems, this);
            if(elementIndex > index){
                index = elementIndex-1;
                change("right");
            }else if(elementIndex < index){
                index = elementIndex+1;
                change("left");
            }
        })
    }

    var myTimeOut = setInterval(function(){
        change("right");
    }, 2000)

    // clearInterval(myTimeOut);

})