window.addEventListener("load", function(){

    var slider = document.querySelector('.slider');
    var leftArrow = document.querySelector('.leftArrow');
    var rightArrow = document.querySelector('.rightArrow');
    
    var images = document.querySelectorAll('ul li img');
    console.log(images);

    slider.style.backgroundImage = "url("+ images[0].getAttribute("src") +")";
    images[0].classList.add("active");

    rightArrow.addEventListener("click", function(){
        changeImg("right");
    })

    leftArrow.addEventListener("click", function(){
        changeImg("left");
    })

    function changeImg(dir){
        var activeImg = document.querySelector('img.active');
        activeImg.classList.remove("active");
        var nextImg;
        if(dir == "right"){
            var nextEl = activeImg.parentElement.nextElementSibling;
            if(nextEl){
                nextImg = nextEl.children[0];
            }else{
                nextImg = document.querySelector('ul li img');
            }
        }else if("left"){
            var prevEl = activeImg.parentElement.previousElementSibling;
            if(prevEl){
                nextImg = prevEl.children[0];
            }else{
                nextImg = document.querySelector('ul li:last-child img');
            }
        }
        
        nextImg.classList.add("active");
        var src = nextImg.getAttribute("src");
        slider.style.backgroundImage = "url(" + src + ")";
    }
})