# p204-24-11-2017

Dərsdə yazdığımız Slider-in hər iki variantını yuxarıda tapa bilərsiniz. 

### Tapşırıq (Template)
- Template-i dünəndən göndərmişəm. Onu bitirməlisiniz. 

### Tapşırıq (JS)
- Tapşırığı videoya yazıb Google Drive-a atacam, baxıb yazarsınız.

*Uğurlar. Sabah lab-da görüşərik.*
